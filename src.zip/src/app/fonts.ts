import { Inter } from "next/font/google";

export const inter = Inter({
  weight: ["500", "600", "700"],
  subsets: ["latin", "cyrillic"],
  variable: "--font-inter",
});
