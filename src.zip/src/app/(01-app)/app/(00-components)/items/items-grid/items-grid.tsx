"use client";

import styles from "./items-grid.module.scss";
import AddItemForm from "@/app/(01-app)/app/(00-components)/items/add-item-form/add-item-form";
import FeatherIcon from "feather-icons-react";
import Link from "next/link";
import { useUI } from "@/app/(02-rest)/providers/UIProvider";
import { SupabaseAlbum, SupabaseTrack } from "@/types/items";
import { useTotalItemIds } from "@/hooks/items/use-total-item-ids";
import { useUserData } from "@/app/(02-rest)/providers/DataProvider";
import { findItemType } from "@/hooks/items";
import { itemIsAdded } from "@/hooks/items";

export default function ItemsGrid({
  items,
  publicId,
}: {
  items: SupabaseAlbum[] | SupabaseTrack[];
  publicId: string;
}) {
  const { showModal } = useUI();
  console.log("айтемы для демонстрации -", items);

  const { user } = useUserData();
  const { data: totalItemIds } = useTotalItemIds(user?.userId ?? "");

  function getArtistsList(item: SupabaseAlbum | SupabaseTrack) {
    if (!item.artists?.length) return "Не указано";
    const list = item.artists.map((artist) => artist.name).join(", ");
    return list;
  }
  function openPopupAddAlbum(item: SupabaseAlbum | SupabaseTrack) {
    showModal(<AddItemForm item={item}></AddItemForm>);
  }

  return (
    <div className={styles.items_grid}>
      {items.map((item) => {
        const added = itemIsAdded(item, totalItemIds);
        return (
          <Link
            key={item.id}
            className={
              styles.items_grid__item + (added ? ` ${styles.added}` : "")
            }
            href={`/app/folder/${publicId}/item/${item.item_id}/`}
          >
            <div className={styles.items_grid__item_top}>
              <div
                className={styles.item_grid__item_like}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation(); // ← ключевой момент
                  openPopupAddAlbum(item);
                }}
              >
                {added ? (
                  <FeatherIcon icon="check" />
                ) : (
                  <FeatherIcon icon="plus" />
                )}
              </div>
              <img
                src={item.images[1].url}
                className={styles.items_grid__item_img}
                alt=""
              />
            </div>
            <div className={styles.item_grid__item_bottom}>
              <div className={styles.item_grid__item_name}>{item.name}</div>
              <div className={styles.item_grid__item_meta}>
                <span>{getArtistsList(item)}</span> -{" "}
                <span>{findItemType(item)}</span>
              </div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}
